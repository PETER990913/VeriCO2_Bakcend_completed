const scope = {
    "Net Zero": [
        727358.0, 243247.0
    ],

    "Dust": [
        12398.0, 342871.0
    ]
}
module.exports = scope;
