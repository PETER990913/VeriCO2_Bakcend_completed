module.exports = {
    secret: "super_ninja_fi"
};