module.exports = {
    url: "mongodb://localhost:27017/demo"
  // url: "mongodb+srv://jeremyt1132:AlBsrejO9uAgtJIM@freedb.yul9lsv.mongodb.net/mydatabase"
};